# Handoff: Menstrual Cycle Education Site (Home, Purpose, Model shell, Sources/Support)

## Overview
A redesign of the site surrounding an existing menstrual-cycle simulation ("Model" page). Covers Home, Purpose, Sources/Support, shared navigation, and shared footer. Built to be recreated in the target Next.js codebase.

## About the Design Files
`Site.dc.html` in this bundle is a **design reference** built in an HTML prototyping tool — not production code to copy directly. Recreate this design as React/Next.js components using the project's existing patterns (routing, component structure, CSS approach). If the project has no established styling system yet, plain CSS modules or the codebase's existing convention is fine — match the values below exactly.

## Fidelity
**High-fidelity.** All colors, type sizes, spacing, radii, and shadows below are final pixel/value specs — recreate pixel-perfectly.

## ⚠ Protected component: the Model page simulation
The Model page currently in production contains a working, fully-built simulation (timeline slider, hormone curves, anatomy stages, "What Happens Next" controls, state management). **Do not touch, recreate, replace, or refactor its internals.** In this design bundle the Model page is only a shell/wrapper — the dashed placeholder box in `Site.dc.html`'s Model section marks where the real, existing simulation component mounts unchanged. Implement only the header text and wrapper card around it; leave the simulation's own component tree, hormone logic, animation, and state entirely alone.

Also protected/already correct in the live Next.js app: the curved title text "The Menstrual Cycle: A Simulation" on the Home hero — it is already implemented correctly there; do not rebuild it from this HTML (the HTML version renders it as a plain non-curved heading placeholder).

## Global layout & shared components

### Fonts
- Headings/buttons/nav: **Fredoka**, weights 500/600/700
- Body text: **Quicksand**, weights 400–700
- Load via Google Fonts: `family=Fredoka:wght@500;600;700&family=Quicksand:wght@400;500;600;700`

### Color palette
- Page background (default): `#fdf1ef`
- Section background (light pink): `#FBE3E8`
- Section background (paler pink): `#FDF3F2`
- Dark rose band (OR divider section): `#a24f61`
- Footer band: `#f2a3b8`
- Card surface (opaque): `#fffaf9`
- Card surface (Guidance, filled): `#f6b9c9`
- Heading red/rose: `#b45c69`, `#8a4356`
- Body text rose-brown: `#8a4b58`, `#7a3c4a`
- Accent rose (arrows, links, underline): `#c66d86`
- Muted rose text (footer, OR label): `#c68195`, `#f3c4d0`
- Link default: `#c66d86`; link hover: `#8a4356`

### Nav (all pages, sticky)
- `position: sticky; top:0`, background `#fdf1ef`, bottom border **10px solid white**
- Padding `14px` vertical, `clamp(20px,4vw,48px)` horizontal
- Left: logo image (`assets/logo-new.png`, line-art logo, transparent background) at **46.2px height**, plus 2-line wordmark "The Menstrual / Cycle" (Fredoka 600, 15px, color `#8a4356`), 10px gap. Clicking the logo navigates Home.
- Desktop (≥761px): horizontal nav links — Home, Purpose, Model, Sources. Fredoka 500, 19px, color `#8a4356`. Active link gets a 2px solid `#c66d86` bottom border; inactive links have transparent 2px border reserved (no layout shift).
- Mobile (≤760px): hamburger button (3 bars, 26×3px, `#8a4356`, 5px gap) replaces the link row. Tapping opens a dropdown panel (slides down, 0.18s ease-out) listing the same 4 links stacked, each with a 1px bottom divider (`rgba(138,67,86,0.08)`), 12px vertical padding. Selecting a link or the logo closes the menu.
- Breakpoint: `760px` max-width via `matchMedia`.

### Footer (all pages)
- Scalloped divider: 22px tall, `radial-gradient(circle at 13.2px 0, transparent 13.2px, #f2a3b8 14.3px)`, repeated horizontally every 26.4px (`background-size:26.4px 22px; repeat-x`) — draws a row of pink half-circle scallops.
- Band below: background `#f2a3b8`, padding `15px` top / `clamp(20px,5vw,48px)` sides / `24px` bottom, `min-height:89px`, centered text.
- Content (shifted up 8px via inner wrapper `translateY(-8px)`):
  - "KEY NOTE" label — Fredoka 600, 13px, letter-spacing 0.3px, color `#b45c69`
  - Body copy, max-width 900px, centered, 13px/1.55 line-height, color `#b45c69`: *"This is not a diagnostic tool — it is solely for education and empowerment. If you have personal health concerns, please consult a professional medical provider. Visuals are simplified and may not be anatomically precise; hormone levels and cycle timing vary between individuals."*

### Responsive rules
- No fixed pixel widths/heights anywhere that could clip text on narrow screens — use `clamp()`, `min()`, `%`.
- OR-row (Freedom/Guidance cards) stacks vertically below 560px viewport width (`flex-direction:column` in a max-width:560px media query).
- All section paddings scale via `clamp()`.

---

## Page: Home
Default/landing page (`isHome`).

### Hero section
- Background `#fbe3e8`, fixed height **460px** (design note: intentionally not min-height — content is short and positioned absolutely inside), `position:relative`, padding `clamp(48px,8vw,96px) clamp(20px,5vw,48px) clamp(56px,7vw,80px)`, text centered.
- **Title** (already correctly implemented as curved text in the live Next.js app — do not rebuild from this file): "The Menstrual Cycle: A Simulation". In this HTML reference it's rendered as Fredoka 700, `clamp(34px,5.2vw,58px)`, color `#b45c69`, line-height 1.1, shifted up 23px.
- **Button** "Open Model" — pill shape, background `#fffaf9`, text color `#c66d86`, Fredoka 600, 20px, padding `16px 44px`, `border-radius:999px`, shadow `0 6px 18px rgba(138,67,86,0.14)`. Absolutely centered horizontally, `top:217px`. Hover: lifts `translateY(-2px)` + deeper shadow `0 8px 22px rgba(138,67,86,0.2)`. Navigates to Model page.
- **Subtext**, absolutely positioned, centered, `top:257px`, max-width `min(600px,88vw)`: Fredoka body, `clamp(18px,2.4vw,22px)`, color `#8a4b58`: *"An interactive educational model of menstrual physiology and reproductive endocrinology."*

### "What You'll Explore" section
- Background `#FDF3F2`, min-height 500px, flex row (wraps), gap `clamp(32px,5vw,64px)`, padding `clamp(20px,5vw,48px)` (bottom reduced by 15px), centered.
- Left column (flex 1 1 420px, shifted down 10px total via `translateY(calc(-5% + 10px))`):
  - Heading "What You'll Explore" — Fredoka 600, `clamp(26px,3vw,34px)`, color `#8a4356`.
  - 5 bullet rows, each: a rose (`#c66d86`) bold "→" arrow (18px) + paragraph (18px/1.6, color `#8a4b58`), arrow and text inline (flex row, 10px gap) so wrapped lines stay flush with text, not under the arrow. Copy:
    1. "How the brain, pituitary, and ovaries communicate through hormone signals"
    2. "Why ovulation requires a specific sequence of biological events, not just a fixed day"
    3. "How different structures respond to signaling and maintain feedback"
    4. "How the uterine lining builds and sheds in response to hormones"
    5. "Various physiological changes that can disrupt the cycle and lead to abnormalities"
- Right column: circular image placeholder, `max-width:min(459px,60vw)`, aspect-ratio 1:1, shifted up 5% (`translateY(-5%)`). **Placeholder asset** — brain-to-ovaries hormone diagram illustration needed.

### "Freedom / Guidance" band
- Dark rose section, background `#a24f61`, padding `clamp(5px,calc(4vw-15px),29px)` top / `clamp(20px,5vw,48px)` sides / `clamp(0px,calc(4vw-20px),24px)` bottom (top padding is 5px taller than bottom — intentional asymmetry).
- Inner row: max-width 1000px, centered, flex, gap 20px, wraps; **stacks vertically below 560px viewport width**.
- **Freedom card**: background `#fffaf9`, radius 24px, padding 20px (top padding 44px to clear the icon), centered text, `position:relative`.
  - Circle icon placeholder, 52.8×52.8px, absolutely centered on top edge at `top:-18.7px`. **Placeholder** — needs an icon graphic.
  - Title "Freedom" — Fredoka 600, 32.2px, color `#e79ab1`.
  - Body: 20.7px/1.5, color `#c68195`: *"Drag the timeline slider & learn at your own individualistic pace"*
- Middle divider: italic "OR", Fredoka, color `#f3c4d0`, 30px.
- **Guidance card**: background `#f6b9c9` (filled, not white), same shape/padding as Freedom.
  - Circle icon placeholder, same size/position. **Placeholder**.
  - Title "Guidance" — Fredoka 600, 32.2px, color `#fffaf9`.
  - Body: 20.7px/1.5, color `#fdeef1`: *"Use the "What Happens Next" button for structured guidance"*

### Closing statement section
- Background `#fbe3e8`, height 210px, padding `clamp(40px,6vw,64px) clamp(20px,5vw,48px)`.
- Bordered paragraph: max-width 990px, centered, `clamp(18px,2.2vw,21px)`/1.6, color `#8a4b58`, **3px solid `#c66d86` border**, radius 16px, padding `16px 22px`, shifted up 35px. Copy: *"The menstrual cycle, or period, is a natural biological process that reflects overall health and development. It's one of the bodies way of signaling vitality, but it can also bring physical and emotional challenges worth understanding and addressing holistically."*

---

## Page: Purpose

- Container: max-width 1160px, centered, background `#FBE3E8`, padding `clamp(28.8px,4.2vw,43.2px) clamp(20px,5vw,48px)`.

### Hero row (title + illustration)
Flex row, wraps, gap `clamp(24px,4vw,48px)`, vertically centered, shifted up 15% (`translateY(-15%)`); negative bottom margin (`-138px`) intentionally pulls the cards row below up so it overlaps the illustration's bottom ~10%.
- **Left**: 
  - "Purpose" — Fredoka 700, `clamp(49px,5.06vw,63px)`, color `#b45c69`.
  - Small divider: 64×3px rose (`#c66d86`) bar + heart glyph "♥" (18px, `#c66d86`), 10px gap.
  - Subtext, max-width 480px, `clamp(18px,2vw,22px)`/1.55, color `#8a4b58`: *"Understanding the menstrual cycle is a crucial step toward understanding your health."*
- **Right**: organic illustration composition —
  - Background: layered abstract SVG blobs (soft radial gradients, no straight edges) — 3 overlapping curved shapes in `#ffd7e0`, `#f6b9c9`, `#e79ab1` (last at 50% opacity), sized to `min(560px,80vw)`, centered behind the figure, fading to transparent at edges.
  - Foreground: **woman illustration image**, transparent background (background removed via flood-fill from a photo of a woman), `max-width:min(478.4px,77.28vw)`. **Placeholder art** — final illustration asset needed; must extend naturally past the blob edges into the page's pink background (not boxed/circled).

### Two info cards
Flex row, gap 28px, wraps, shifted up 20px (`translateY(-20px)`) as a pair — relative position to the hero row above is intentionally set so Mechanism card visually overlaps ~10% of the illustration's bottom.
- Both cards: **opaque** `#fffaf9` background (not translucent), radius 24px, padding `clamp(28px,4vw,40px)`, shadow `0 8px 24px rgba(138,67,86,0.08)`, equal height (`height:100%` on a flex-stretch parent) so both stay the same size regardless of copy length or screen width — never stretch text/font-size to equalize, only the box.
- Card header: 64×64px circle icon placeholder + heading inline (flex row, 16px gap, left-aligned; if the heading wraps to 2 lines it stays left-aligned, not centered).
- **Card 1 — "Created by women, for women"** (icon placeholder + heading, Fredoka 600, 25px, `#8a4356`). Body copy (18px/1.65, `#8a4b58`): *"For those struggling with the beginning of a new cycle, amenorrhea, PCOS, endometriosis, and more, or simply seeking to gain a better understanding of their body. Reliable information, support, and grace is not always easily accessible. Moreover, it can be incredibly difficult to discover comprehensible sources without fears of shame and belittlement. This simulation is meant to provide baseline knowledge and help connect the dots behind a period. Ultimately, the knowledge serves as a tool of empowerment; empowerment and the ability to advocate for yourself."*
- **Card 2 — "Mechanism over memorization"** (icon placeholder + heading, same style). Body copy (18px/1.65, `#8a4b58`, with the word "why" underlined): *"Most menstrual health resources teach "ovulation happens on day 14". Although equally as important, this simulation focuses on why ovulation happens: through the orderly sequence of hormonal signals and biological states that drive its chain of events. Cycle timing varies between individuals and across life circumstances, therefore understanding the mechanism makes that variability easier to digest and seek help if needed. Additionally, the extenuating circumstances that can cause an abnormal menstrual cycle are also explored."*

---

## Page: Model (shell only — protected simulation inside)

- Container: max-width 1200px, centered, padding `clamp(40px,6vw,64px) clamp(20px,5vw,48px)`.
- Heading "Explore the Model" — Fredoka 700, `clamp(30px,4vw,42px)`, color `#8a4356`, centered.
- Subtext, max-width 680px, centered, 18px/1.6, color `#8a4b58`: *"Drag the timeline or use "What Happens Next" to move through a full cycle and see how hormones drive each stage."*
- Wrapper card: background `#fdf3f2`, radius 28px, padding `clamp(16px,3vw,28px)`, shadow `0 10px 30px rgba(138,67,86,0.1)`.
- Inside the card: **this is where the existing, already-functional simulation component mounts, completely unchanged.** The dashed-border placeholder box in the HTML reference (2px dashed `#e7a9bb`, 16:9 aspect-ratio, radius 20px, background `#fffaf9`) is only a stand-in to show the mount point/sizing — do not build anything inside it; wire up the real component there instead.

---

## Page: Sources (also includes Support section)

- Container: max-width 960px, centered, padding `clamp(40px,6vw,64px) clamp(20px,5vw,48px)`.
- Heading "Sources" — Fredoka 700, `clamp(30px,4vw,42px)`, color `#B45C69`, centered.
- Subtext, centered, 17px, color `#8a4b58`: *"Created by one high school student with the assistance of many reference resources."*
- **Sources list**: single card, background `#fdf3f2`, radius 20px, padding 8px, shadow `0 8px 24px rgba(138,67,86,0.08)`. Each row: 20px/22px padding, 1px bottom divider `rgba(138,67,86,0.08)` (last row's divider can remain or be removed — currently always present). Row content: name (Fredoka 600, 17px, `#8a4356`) + description (15px/1.55, `#8a4b58`).
  1. American College of Obstetricians and Gynecologists (ACOG) — "Clinical Guidance, Committee Opinions, Practice Bulletins, and Patient Education."
  2. Williams Gynecology — "Hoffman, B. L., Schorge, J. O., Halvorson, L. M., et al. McGraw Hill Education, via McGraw Hill AccessMedicine."
  3. Endocrine Society Clinical Practice Guidelines — "Endocrine Society. Clinical Practice Guidelines."
  4. American Society for Reproductive Medicine (ASRM) — "Practice Committee Guidelines and Patient Education."
  5. International Evidence-based Guideline for PCOS — "Monash University, ASRM, ESHRE, and collaborating organizations. International Evidence-Based Guideline for the Assessment and Management of Polycystic Ovary Syndrome."
  6. StatPearls / NCBI Bookshelf — "StatPearls Publishing, hosted by the National Center for Biotechnology Information."
- **Support section** (heading "Support", Fredoka 600, 26px, `#B45C69`, margin-top `clamp(40px,5vw,56px)`): **grid** (distinct layout from the Sources list) — `repeat(auto-fit,minmax(260px,1fr))`, 16px gap. Each card: background `#fdf3f2`, radius 18px, padding `20px 22px`, shadow `0 6px 16px rgba(138,67,86,0.07)`. Contains a pill-shaped focus-area tag (background `#f6b9c9`, text `#7a3346`, Fredoka 600, 12px, letter-spacing 0.3px, padding `4px 12px`, radius 999px), then name (Fredoka 600, 16px, `#8a4356`), then description (14px/1.55, `#8a4b58`).
  1. Office on Women's Health (U.S. Department of Health and Human Services) — Focus: "General Women's Health" — "A trusted U.S. government resource providing evidence-based information on menstrual health, PCOS, endometriosis, menopause, contraception, pregnancy, and other reproductive health topics."
  2. PCOS Challenge — Focus: "PCOS" — "A nonprofit dedicated to PCOS education, advocacy, and support. Offers educational resources, webinars, patient conferences, and peer support communities."
  3. International Association for Premenstrual Disorders (IAPMD) — Focus: "PMDD & PME" — "Provides education, symptom tracking tools, moderated support groups, and resources for individuals affected by PMDD and other severe premenstrual disorders."
  4. RESOLVE: The National Infertility Association — Focus: "Fertility & Amenorrhea" — "Offers free peer-led support groups, educational resources, and advocacy for individuals experiencing infertility and ovulatory disorders, including some causes of amenorrhea."
  5. Anxiety and Depression Association of America (ADAA) — Focus: "Stress & Mental Health" — "Provides evidence-based resources, therapist directories, and educational materials for managing stress, anxiety, and depression, which can influence menstrual health."
  6. The Pad Project — Focus: "Menstrual Equity" — "A nonprofit working to reduce period poverty by providing menstrual products, education, and advocacy for underserved communities around the world."

---

## External links
No inline hyperlinks are wired up in the current build — the Sources and Support entries are text cards, not links. **Recommendation:** centralize the destination URLs for each of the 6 sources and 6 support organizations in one config/data file (e.g. `data/sources.ts`) during implementation, so links can be added/edited in one place rather than scattered across markup. Visible labels are listed above; actual destination URLs were not provided in this design pass and should be sourced/confirmed before implementation, or the entries left as plain text if no link is intended.

## Navigation behavior (state model reference)
Single-page state machine with 4 routes: `home | purpose | model | sources`. Nav highlights the active route with a 2px bottom border. Mobile menu closes on any nav selection. In the target Next.js app, implement as real routes/pages (e.g. `/`, `/purpose`, `/model`, `/sources`) rather than client-side state, with the same nav visuals and active-state styling.

## Images & assets in this bundle
- `assets/logo-new.png` — line-art logo, transparent background, used at 46.2px height in nav.
- `assets/purpose-woman-illustration.png` — woman illustration with background removed (transparent), used on Purpose page. Treat as a placeholder-quality asset; replace with final art if available, keeping the transparent background and "extends past the gradient blobs" behavior.
- `assets/mechanism-graphic-pink.png` — an earlier decorative graphic, **no longer used** in the current design (removed from Purpose cards); can be discarded.
- **Placeholder image slots to fill in implementation** (currently empty drop-targets in the HTML reference, not real assets):
  - Home "What You'll Explore" — circular brain-to-ovaries hormone diagram illustration.
  - Home Freedom/Guidance band — 2 small circular icons (one per card).
  - Purpose page — hero illustration (see above, already has a placeholder asset), plus 2 small circular icons in the "Created by..." and "Mechanism..." card headers.

## Files
- `Site.dc.html` — full design reference (all pages, shared nav/footer, inline styles, component logic for page routing).
- `assets/` — image assets described above.
- `screenshots/` — reference screenshots: `01-home.png`, `02-purpose.png`, `03-model.png` (shell only), `04-sources.png`.
